Team Sirloin

Daniil Borisov
Travis Morasch
Brian Velez

Output formatting(whitespace, tabbing) differs between source and output but compiling of output produces a steady state this aside(outputs are all identical)

Diff done on Windows 8 machine using Meld diff program for Windows.