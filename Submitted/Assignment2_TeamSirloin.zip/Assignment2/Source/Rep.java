public class Rep {
	static String me = "public class Rep { static String me = ;public static void main(String[] args) { char d = 34; System.out.println( me.substring(0,38) + d + me + d + me.substring(38,173)); } }";
	public static void main(String[] args) {
		char d = 34;
		System.out.println( me.substring(0,38) + d + me + d + me.substring(38,173));
	}
}
